# ENEM AI - Plataforma de Estudos Inteligente

Uma plataforma completa de estudos para o ENEM que utiliza inteligência artificial para ajudar estudantes e professores.

## 🚀 Funcionalidades Implementadas

### FASE 1: Estrutura Base
- ✅ Landing page responsiva com design moderno
- ✅ Sistema de autenticação local (login/registro)
- ✅ Dashboard protegido por autenticação
- ✅ Estrutura de arquivos organizada

### FASE 2: Editor Rico e IA
- ✅ Editor de texto rico com formatação completa
- ✅ Integração com Google Gemini API
- ✅ Chat interativo com IA
- ✅ Botões de ação rápida (melhorar texto, corrigir gramática, resumir, explicar)
- ✅ Salvamento automático de anotações
- ✅ Sistema de anotações com LocalStorage

### FASE 3: Funcionalidades Avançadas ✅
- ✅ **Sistema de Busca Inteligente**: Busca em tempo real por conteúdo e tags
- ✅ **Sistema de Favoritos**: Marcar/desmarcar anotações favoritas
- ✅ **Sistema de Tags/Categorias**: Organização por tags coloridas
- ✅ **Exportação de Anotações**: Download em formato .txt
- ✅ **Atalhos de Teclado**: Ctrl+S (salvar), Ctrl+N (nova), Ctrl+B/I/U (formatação)
- ✅ **Filtros Avançados**: Por tags, favoritos e busca textual
- ✅ **Sistema de Notificações**: Toast notifications para feedback
- ✅ **Melhorias de UX**: Placeholders, tooltips, animações
- ✅ **Interface Responsiva**: Funciona em desktop e mobile

## 🛠️ Tecnologias Utilizadas

- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Styling**: Tailwind CSS
- **Ícones**: Font Awesome
- **IA**: Google Gemini API
- **Armazenamento**: LocalStorage

## 📁 Estrutura do Projeto

```
Students-use-AI/
├── homepage.html          # Landing page pública
├── server.py             # Servidor local Python
├── public/
│   ├── login.html         # Página de login/registro
│   ├── dashboard.html     # Dashboard principal com editor
│   └── index.html         # Redirecionamento
├── src/
│   └── scripts/
│       └── main.js        # Scripts auxiliares
└── README.md
```

## 🎯 Funcionalidades Detalhadas

### Editor Rico
- **Formatação**: Negrito, itálico, sublinhado
- **Títulos**: H1, H2, H3
- **Listas**: Numeradas e com marcadores
- **Alinhamento**: Esquerda, centro, direita
- **Links**: Inserção de URLs
- **Cores**: Seletor de cor para texto

### Assistente IA
- **Melhorar Texto**: Reescrita com melhor clareza
- **Corrigir Gramática**: Correção de erros ortográficos
- **Resumir**: Criação de resumos concisos
- **Explicar Conceitos**: Explicações didáticas
- **Chat Livre**: Perguntas personalizadas sobre o conteúdo

### Sistema de Anotações
- **Criação**: Editor rico com formatação
- **Salvamento**: Automático a cada 3 segundos
- **Organização**: Tags coloridas e categorização
- **Busca**: Filtros por texto, tags e favoritos
- **Exportação**: Download em formato texto
- **Favoritos**: Sistema de marcação de anotações importantes

### Atalhos de Teclado
- `Ctrl + S`: Salvar anotação
- `Ctrl + N`: Nova anotação
- `Ctrl + B`: Negrito
- `Ctrl + I`: Itálico
- `Ctrl + U`: Sublinhado

## 🔧 Configuração e Execução

### Pré-requisitos
- Python 3.6 ou superior instalado
- Navegador web moderno (Chrome, Firefox, Safari, Edge)

### 1. Clone ou baixe o projeto
```bash
git clone [URL_DO_REPOSITORIO]
cd Students-use-AI
```

### 2. Configure a API Key do Google Gemini
- Acesse [Google AI Studio](https://makersuite.google.com/app/apikey)
- Crie uma nova API key
- Substitua `GEMINI_API_KEY` no arquivo `public/dashboard.html`

### 3. Execute o servidor local

#### Opção 1: Usando Python (Recomendado)
```bash
python server.py
```

#### Opção 2: Usando Python 3 (se necessário)
```bash
python3 server.py
```

#### Opção 3: Servidor Python simples (alternativa)
```bash
python -m http.server 8000
```

### 4. Acesse o site
Após executar o comando, o navegador abrirá automaticamente. Caso contrário, acesse:

- **Homepage**: http://localhost:8000/homepage.html
- **Login**: http://localhost:8000/public/login.html  
- **Dashboard**: http://localhost:8000/public/dashboard.html

### 5. Parar o servidor
Pressione `Ctrl + C` no terminal para parar o servidor.

## 🎨 Design e UX

- **Interface Moderna**: Design limpo e profissional
- **Responsivo**: Funciona em todos os dispositivos
- **Animações**: Transições suaves e feedback visual
- **Acessibilidade**: Navegação por teclado e leitores de tela
- **Feedback**: Notificações toast para todas as ações

## 🔒 Segurança

- **Autenticação Local**: Sistema de login/registro
- **Proteção de Rotas**: Dashboard só acessível após login
- **Dados Locais**: Anotações salvas no navegador do usuário
- **API Segura**: Chave da API protegida no frontend

## 🚀 Próximas Funcionalidades

- [ ] Sincronização em nuvem
- [ ] Compartilhamento de anotações
- [ ] Templates de anotações
- [ ] Estatísticas de estudo
- [ ] Modo offline
- [ ] Integração com calendário
- [ ] Backup automático

## 📞 Suporte

Para dúvidas ou sugestões, entre em contato através do email: contato@enemai.com.br

---

**ENEM AI** - Transformando a forma de estudar para o ENEM com inteligência artificial! 🧠✨ 